package com.letrasypapeles.backend.entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity
@Table(name = "roles")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Role {

    @Id
    private String nombre;

    @ManyToMany(mappedBy = "roles")
    private Set<Cliente> clientes;
}
